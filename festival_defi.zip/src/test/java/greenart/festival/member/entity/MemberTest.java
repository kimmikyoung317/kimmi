package greenart.festival.member.entity;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemberTest {

//    @Autowired
//    private BoardService boardService;
//    @Test
//    void searchBoard(){
//        Board board = boardService.getBoard(1L);
//        System.out.println("board = " + board);
//    }
//
//    @Test
//    void addReview() {
//        Review review = new Review();
//
//    }
}