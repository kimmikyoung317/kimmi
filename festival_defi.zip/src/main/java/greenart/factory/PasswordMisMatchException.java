package greenart.factory;

public class PasswordMisMatchException extends RuntimeException{
}
