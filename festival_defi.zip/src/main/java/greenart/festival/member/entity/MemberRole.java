package greenart.festival.member.entity;

public enum MemberRole {
    USER, ADMIN
}
