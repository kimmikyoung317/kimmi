package greenart.festival.member.entity;

public enum Social {
    NONE, GOOGLE, NAVER, KAKAO
}
