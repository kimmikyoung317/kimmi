package greenart.festival.review.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceExam {

//    @Autowired
//    private ReviewRepository reviewRepository;

      // 리뷰 신고 (부적절한 리뷰 처리)
//    public void reportReview(Long reviewId){
//        // 신고된 리뷰 처리 로직 (예: flagged 상태로 변경)
//        Review review = reviewRepository.findById(reviewId)
//                .orElseThrow(() -> new RuntimeException("리뷰를 찾을 수 없습니다."));
//        review.setFlagged(true); // 리뷰 신고 처리
//        reviewRepository.save(review); // 변경사항 저장
//    }

}
